﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Xml;


namespace Testa_Uzdevums_Karlis
{
    public class CurrencyRate
    {
        public string CurrencyCode { get; set; }
        public decimal Rate { get; set; }
    }

    public class CurrencyRatesReader
    {
        public List<CurrencyRate> ReadCurrencyRatesFromXml(string xmlUrl)
        {
            List<CurrencyRate> rates = new List<CurrencyRate>();

            try
            {
                using (WebClient client = new WebClient())
                {
                    string xmlData = client.DownloadString(xmlUrl);
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(xmlData);

                    XmlNodeList currencyNodes = xmlDoc.SelectNodes("//Currency");
                    foreach (XmlNode currencyNode in currencyNodes)
                    {
                        CurrencyRate rate = new CurrencyRate
                        {
                            CurrencyCode = currencyNode.SelectSingleNode("ID").InnerText,
                            Rate = Convert.ToDecimal(currencyNode.SelectSingleNode("Rate").InnerText)
                        };
                        rates.Add(rate);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading currency rates: {ex.Message}");
            }

            return rates;
        }
    }
}